from django.apps import AppConfig


class SubPartConfig(AppConfig):
    name = 'sub_part'
