from django.contrib import admin
from . models import reg
# Register your models here.
admin.site.register(reg)
