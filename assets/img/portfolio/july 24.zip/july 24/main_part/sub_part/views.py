from django.shortcuts import render,redirect
from . models import reg
from django.contrib import messages
# Create your views here.
def home(request):

    return render(request,'home.html')


def home_reg(request):
    if request.method=='POST':
        ex1=reg(first_name=request.POST['first_name'],
                last_name=request.POST['last_name'],
                email_id=request.POST['email_id'],
                phone_number=request.POST['phone_number'],
                user_name=request.POST['user_name'],
                password=request.POST['password'])
        ex1.save()
        messages.error(request,'your data has been successfully saved in database')
        return redirect(home)
        
    return render(request,'home.html')

